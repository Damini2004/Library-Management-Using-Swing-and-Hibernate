package com.cse.LibraryManagement;


import java.awt.BorderLayout;

import javax.swing.*;

public class Home {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame mainFrame = new JFrame("Library Management System");
            mainFrame.setSize(800, 600);
            mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            mainFrame.setLocationRelativeTo(null);

            JTabbedPane tabbedPane = new JTabbedPane();

            // Home panel
            JPanel homePanel = new JPanel();
            homePanel.setLayout(new BorderLayout());
            JLabel homeImage = new JLabel(new ImageIcon("path/to/library-image.jpg"));
            homePanel.add(homeImage, BorderLayout.CENTER);
            tabbedPane.addTab("Home", homePanel);

            /// Signup panel
            JPanel signupPanel = new JPanel();
            signupPanel.setLayout(new BorderLayout()); // Ensure proper layout
            RegistrationUI registrationUI = new RegistrationUI();
            signupPanel.add(registrationUI.getMainPanel(), BorderLayout.CENTER); // Assuming getMainPanel() returns the main panel of RegistrationUI
            tabbedPane.addTab("Signup", signupPanel);

            // Login panel
            JPanel loginPanel = new JPanel();
            loginPanel.setLayout(new BorderLayout()); // Ensure proper layout
            Login librarySignupLoginGUI = new Login();
            loginPanel.add(librarySignupLoginGUI.getMainPanel(), BorderLayout.CENTER); // Assuming getMainPanel() returns the main panel of RegistrationUI
            tabbedPane.addTab("Login", loginPanel);


            mainFrame.add(tabbedPane);
            mainFrame.setVisible(true);
        });
    }
}
