package com.cse.LibraryManagement;

import javax.swing.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Pattern;

public class RegistrationUI extends JFrame {
    private JPanel mainPanel;
    private JTextField studentIdField;
    private JTextField studentNameField;
    private JTextField studentBranchField;
    private JTextField emailField;
    private JPasswordField passwordField;

    public RegistrationUI() {
        mainPanel = new JPanel();
        mainPanel.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Student ID
        gbc.gridx = 0;
        gbc.gridy = 0;
        mainPanel.add(new JLabel("Student ID:"), gbc);
        gbc.gridx = 1;
        studentIdField = new JTextField(20);
        mainPanel.add(studentIdField, gbc);

        // Student Name
        gbc.gridx = 0;
        gbc.gridy = 1;
        mainPanel.add(new JLabel("Student Name:"), gbc);
        gbc.gridx = 1;
        studentNameField = new JTextField(20);
        mainPanel.add(studentNameField, gbc);

        // Student Branch
        gbc.gridx = 0;
        gbc.gridy = 2;
        mainPanel.add(new JLabel("Student Branch:"), gbc);
        gbc.gridx = 1;
        studentBranchField = new JTextField(20);
        mainPanel.add(studentBranchField, gbc);

        // Email
        gbc.gridx = 0;
        gbc.gridy = 3;
        mainPanel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        emailField = new JTextField(20);
        mainPanel.add(emailField, gbc);

        // Password
        gbc.gridx = 0;
        gbc.gridy = 4;
        mainPanel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1;
        passwordField = new JPasswordField(20);
        mainPanel.add(passwordField, gbc);

        // Register Button
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JButton registerButton = new JButton("Register");
        mainPanel.add(registerButton, gbc);

        // Register button action
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateForm()) {
                    String studentId = studentIdField.getText();
                    String studentName = studentNameField.getText();
                    String studentBranch = studentBranchField.getText();
                    String email = emailField.getText();
                    String password = new String(passwordField.getPassword());
                    
                    Configuration con = new Configuration().configure().addAnnotatedClass(Students.class);
                    SessionFactory sf = con.buildSessionFactory();
                    Session s = sf.openSession();
                    Transaction tx = s.beginTransaction();
                    
                    Students st = new Students();
                    st.setStudentId(studentId);
                    st.setStudentName(studentName);
                    st.setStudentBranch(studentBranch);
                    st.setStudentEmail(email);
                    st.setStudentPassword(password);
                    
                    s.save(st);
                    
                    tx.commit();
                    
                    JOptionPane.showMessageDialog(RegistrationUI.this, "Student Registered Successfully!");
                }
            }
        });
    }


    private boolean validateForm() {
        if (studentIdField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Student ID is required.");
            return false;
        }
        if (studentNameField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Student Name is required.");
            return false;
        }
        if (studentBranchField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Student Branch is required.");
            return false;
        }
        if (emailField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Email is required.");
            return false;
        }
        if (!isValidEmail(emailField.getText())) {
            JOptionPane.showMessageDialog(this, "Invalid email format.");
            return false;
        }
        if (passwordField.getPassword().length == 0) {
            JOptionPane.showMessageDialog(this, "Password is required.");
            return false;
        }
        if (passwordField.getPassword().length < 8) {
            JOptionPane.showMessageDialog(this, "Password must be at least 8 characters long.");
            return false;
        }
        return true;
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pat = Pattern.compile(emailRegex);
        return pat.matcher(email).matches();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            RegistrationUI ui = new RegistrationUI();
            ui.setVisible(true);
        });
    }

    public JPanel getMainPanel() {
        return mainPanel;
    }
}
